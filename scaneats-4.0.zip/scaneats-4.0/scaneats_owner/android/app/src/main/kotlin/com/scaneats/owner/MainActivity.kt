package com.scaneats.owner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
