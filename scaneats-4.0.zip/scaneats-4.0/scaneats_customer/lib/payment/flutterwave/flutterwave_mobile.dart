import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutterwave_standard/flutterwave.dart';
import 'package:get/get.dart';
import 'package:scaneats_customer/page/success_page.dart';

setRef() {
  Random numRef = Random();
  int year = DateTime.now().year;
  int refNumber = numRef.nextInt(20000);
  if (Platform.isAndroid) {
    return "AndroidRef$year$refNumber";
  } else if (Platform.isIOS) {
    return "IOSRef$year$refNumber";
  } else {
    return '';
  }
}

flutterWaveInitiatePayment({required BuildContext context, required String publicKey, required String amount}) async {
  final flutterwave = Flutterwave(
    amount: amount,
    currency: 'NGN',
    customer: Customer(name: 'Text', phoneNumber: '8511345401', email: 'mayankmodi1995@gmail.com'),
    context: context,
    publicKey: publicKey,
    paymentOptions: "card, payattitude",
    customization: Customization(title: "Flutterwave"),
    txRef: setRef(),
    isTestMode: true,
    redirectUrl: 'https://google.com',
  );
  final ChargeResponse response = await flutterwave.charge();
  if (response.success!) {
    Get.offAll(const SuccessPage(isSuccess: true));
  }else{
    Get.offAll(const SuccessPage(isSuccess: false));
  }
}
