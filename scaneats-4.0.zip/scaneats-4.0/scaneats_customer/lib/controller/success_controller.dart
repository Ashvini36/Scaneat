import 'dart:async';

import 'package:get/get.dart';
import 'package:scaneats_customer/constant/constant.dart';
import 'package:scaneats_customer/page/pos_screen/navigate_pos_screen.dart';

class SuccessController extends GetxController {
  late Timer timer;

  RxInt start = 5.obs;

  @override
  void onInit() {
    // TODO: implement onInit
    startTimer();
    super.onInit();
  }

  void startTimer() {
    const oneSec = Duration(seconds: 1);
    timer = Timer.periodic(
      oneSec,
      (Timer timer) {
        if (start.value == 0) {
          timer.cancel();
          Constant.paymentStatus = null;
          Get.offAll(const NavigatePosScreen());
        } else {
          start.value--;
        }
      },
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    timer.cancel();
    super.dispose();
  }
}
