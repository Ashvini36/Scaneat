import 'package:get/get.dart';

class ItemTablesController extends GetxController {
  RxString title = "Item Tables Screen".obs;
}
