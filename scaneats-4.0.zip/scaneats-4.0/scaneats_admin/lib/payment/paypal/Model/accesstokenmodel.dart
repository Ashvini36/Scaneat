class AccessToken {
  final String? token;
  final String? message;

  AccessToken({this.token, required this.message});
}
