import 'package:get/get.dart';

class ItemReportController extends GetxController {
  RxString title = "Item Report Screen".obs;
}
