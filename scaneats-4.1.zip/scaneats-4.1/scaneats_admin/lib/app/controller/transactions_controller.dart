import 'package:get/get.dart';

class TransactionsController extends GetxController {
  RxString title = "Transactions Screen".obs;
}
