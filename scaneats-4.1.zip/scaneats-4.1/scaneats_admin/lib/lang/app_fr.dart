const Map<String, String> trFR = {
  'term_service': "Conditions d'utilisation",
};
