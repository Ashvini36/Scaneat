import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:scaneats_customer/controller/pos_controller.dart';
import 'package:scaneats_customer/page/pos_screen/widget_pos_screen.dart';

class PosScreenDesktopScreen extends StatelessWidget {
  final PosController controller;

  const PosScreenDesktopScreen(this.controller, {super.key});

  @override
  Widget build(BuildContext context) {
    return const Column(
      children: [
        Expanded(child: PosView()),
      ],
    );
  }
}
